// ==============================================================
// File generated on Tue Jul 14 19:06:02 EDT 2020
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:36:41 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xcirc_buff_read_many128.h"

extern XCirc_buff_read_many128_Config XCirc_buff_read_many128_ConfigTable[];

XCirc_buff_read_many128_Config *XCirc_buff_read_many128_LookupConfig(u16 DeviceId) {
	XCirc_buff_read_many128_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XCIRC_BUFF_READ_MANY128_NUM_INSTANCES; Index++) {
		if (XCirc_buff_read_many128_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XCirc_buff_read_many128_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XCirc_buff_read_many128_Initialize(XCirc_buff_read_many128 *InstancePtr, u16 DeviceId) {
	XCirc_buff_read_many128_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XCirc_buff_read_many128_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XCirc_buff_read_many128_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

